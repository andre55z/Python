import pytubefix
from pytubefix import YouTube
class Download:
    def __init__(self, url, way):
        self.way = way
        self.url=url
    def baixar(self):
        try:
            user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            yt = YouTube(self.url, use_po_token=True)
            stream = yt.streams.get_highest_resolution()
            stream.download(self.way)
            return True
        except Exception as e:
            print(f"Erro no download: {e}")
            return False
