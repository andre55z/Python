import os
class Way:
    def __init__ (self):
        self.path= os.path.join(os.path.expanduser("~"), "Downloads")

    def get_path(self):
        return self.path