from screen import Tela

class Main:
    pass

Tela()