import tkinter as tk
from tkinter import messagebox
from way import Way
from download import Download

class Tela:
    def __init__(self):
        self.tela = tk.Tk()
        self.tela.geometry("500x200")
        self.tela.configure(bg="light gray")

        self.lbl = tk.Label(self.tela, text="Insira a URL", width=15, height=2, font=("Helvetica", 12), bg="light gray")
        self.lbl.place(x=185, y=40)

        self.txt = tk.Text(self.tela, width=25, height=1)
        self.txt.place(x=150, y=80)

        self.btn = tk.Button(self.tela, text="Download!", width=10, height=2, bg="red", command=self.Down)
        self.btn.place(x=210, y=110)
        
        self.tela.mainloop()

    def Down(self):
        url = self.txt.get("1.0", tk.END).strip()
        if url:
            way = Way()
            download = Download(url, way.get_path())
            if download.baixar():  
                messagebox.showinfo("Sucesso", "Download concluído!")
            else:
                messagebox.showerror("Erro", "Falha no download!")
        else:
            messagebox.showwarning("Entrada inválida", "Por favor, insira uma URL válida.")
        
        



        
if __name__ == "__main__":
            Tela()